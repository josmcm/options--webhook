const http = require("http");

// ── In-memory store ───────────────────────────────────────────────────────────
let marketData = {};
let lastUpdate = null;

// ── CORS headers ──────────────────────────────────────────────────────────────
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json",
};

// ── Server ────────────────────────────────────────────────────────────────────
const server = http.createServer((req, res) => {
  // Handle preflight
  if (req.method === "OPTIONS") {
    res.writeHead(204, CORS);
    res.end();
    return;
  }

  const url = req.url.split("?")[0];

  // ── POST /webhook — receive TradingView alerts ──────────────────────────────
  if (req.method === "POST" && url === "/webhook") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", () => {
      try {
        const data = JSON.parse(body);
        const ticker = (data.ticker || "").toUpperCase().trim();
        if (!ticker) {
          res.writeHead(400, CORS);
          res.end(JSON.stringify({ error: "No ticker provided" }));
          return;
        }

        // Merge new data with existing
        marketData[ticker] = {
          ticker,
          price:        parseFloat(data.price)        || marketData[ticker]?.price || 0,
          open:         parseFloat(data.open)         || marketData[ticker]?.open || 0,
          high:         parseFloat(data.high)         || marketData[ticker]?.high || 0,
          low:          parseFloat(data.low)          || marketData[ticker]?.low || 0,
          volume:       parseFloat(data.volume)       || marketData[ticker]?.volume || 0,
          avgVolume:    parseFloat(data.avgVolume)    || marketData[ticker]?.avgVolume || 0,
          rsi:          parseFloat(data.rsi)          || marketData[ticker]?.rsi || 50,
          ema9:         parseFloat(data.ema9)         || marketData[ticker]?.ema9 || 0,
          ema20:        parseFloat(data.ema20)        || marketData[ticker]?.ema20 || 0,
          vwap:         parseFloat(data.vwap)         || marketData[ticker]?.vwap || 0,
          pdHigh:       parseFloat(data.pdHigh)       || marketData[ticker]?.pdHigh || 0,
          pdLow:        parseFloat(data.pdLow)        || marketData[ticker]?.pdLow || 0,
          aboveEma9:    data.aboveEma9  === "true"    || data.aboveEma9  === true,
          aboveEma20:   data.aboveEma20 === "true"    || data.aboveEma20 === true,
          aboveVwap:    data.aboveVwap  === "true"    || data.aboveVwap  === true,
          volSpike:     data.volSpike   === "true"    || data.volSpike   === true,
          trend:        data.trend      || marketData[ticker]?.trend || "neutral",
          signal:       data.signal     || marketData[ticker]?.signal || "",
          updatedAt:    new Date().toISOString(),
        };

        lastUpdate = new Date().toISOString();
        console.log(`[${lastUpdate}] Updated: ${ticker} @ $${marketData[ticker].price}`);

        res.writeHead(200, CORS);
        res.end(JSON.stringify({ ok: true, ticker, price: marketData[ticker].price }));
      } catch (e) {
        console.error("Parse error:", e.message);
        res.writeHead(400, CORS);
        res.end(JSON.stringify({ error: "Invalid JSON: " + e.message }));
      }
    });
    return;
  }

  // ── GET /data — return all market data ────────────────────────────────────
  if (req.method === "GET" && url === "/data") {
    res.writeHead(200, CORS);
    res.end(JSON.stringify({ data: marketData, lastUpdate, count: Object.keys(marketData).length }));
    return;
  }

  // ── GET /data/:ticker — return single ticker ──────────────────────────────
  if (req.method === "GET" && url.startsWith("/data/")) {
    const ticker = url.split("/data/")[1].toUpperCase();
    if (marketData[ticker]) {
      res.writeHead(200, CORS);
      res.end(JSON.stringify(marketData[ticker]));
    } else {
      res.writeHead(404, CORS);
      res.end(JSON.stringify({ error: `No data for ${ticker}` }));
    }
    return;
  }

  // ── GET /health — ping ────────────────────────────────────────────────────
  if (req.method === "GET" && url === "/health") {
    res.writeHead(200, CORS);
    res.end(JSON.stringify({ status: "ok", tickers: Object.keys(marketData).length, lastUpdate }));
    return;
  }

  // ── GET / — status page ───────────────────────────────────────────────────
  if (req.method === "GET" && url === "/") {
    const html = `<!DOCTYPE html>
<html style="background:#060608;color:#00ff9d;font-family:monospace;padding:40px">
<h1 style="font-size:28px;letter-spacing:4px">WEEKLY OPTIONS WEBHOOK SERVER</h1>
<p style="color:#778">Status: <span style="color:#00ff9d">● LIVE</span></p>
<p style="color:#778">Tickers tracked: <span style="color:#fff">${Object.keys(marketData).length}</span></p>
<p style="color:#778">Last update: <span style="color:#fff">${lastUpdate || "No data yet"}</span></p>
<hr style="border-color:#1a2e22;margin:20px 0"/>
<h3 style="color:#ffd700;letter-spacing:2px">ENDPOINTS</h3>
<p><span style="color:#00ff9d">POST /webhook</span> <span style="color:#445"> — receive TradingView alerts</span></p>
<p><span style="color:#00ff9d">GET  /data</span>    <span style="color:#445"> — all ticker data</span></p>
<p><span style="color:#00ff9d">GET  /data/NVDA</span><span style="color:#445"> — single ticker data</span></p>
<p><span style="color:#00ff9d">GET  /health</span>  <span style="color:#445"> — server status</span></p>
<hr style="border-color:#1a2e22;margin:20px 0"/>
<h3 style="color:#ffd700;letter-spacing:2px">LIVE DATA</h3>
<pre style="color:#c8d0d8;font-size:12px">${JSON.stringify(marketData, null, 2) || "No data yet"}</pre>
</html>`;
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(html);
    return;
  }

  res.writeHead(404, CORS);
  res.end(JSON.stringify({ error: "Not found" }));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Webhook server running on port ${PORT}`);
  console.log(`Endpoints: POST /webhook | GET /data | GET /health`);
});
