# Deploy to Render.com — Step by Step

## Step 1 — Upload to GitHub
1. Go to github.com → New repository
2. Name it: `options-webhook`
3. Make it Public
4. Upload both files: server.js and package.json

## Step 2 — Deploy on Render
1. Go to render.com → New → Web Service
2. Connect your GitHub repo: `options-webhook`
3. Fill in these settings:
   - Name: `options-webhook`
   - Environment: `Node`
   - Build Command: `npm install`
   - Start Command: `node server.js`
   - Plan: **Free**
4. Click **Create Web Service**
5. Wait ~2 minutes for deploy
6. Copy your URL — looks like: `https://options-webhook-xxxx.onrender.com`

## Step 3 — Test it
Open your browser and go to:
`https://your-url.onrender.com/health`

You should see: `{"status":"ok","tickers":0,"lastUpdate":null}`

## Step 4 — Add to TradingView
Your webhook URL is:
`https://your-url.onrender.com/webhook`

Paste this into every TradingView alert you create.

## Step 5 — Add to the Scanner App
Paste your server URL into the settings panel in the app.
