import { useState, useEffect, useRef } from "react";

// ── Static fallback data ──────────────────────────────────────────────────────
const STATIC_DB = [
  { ticker:"MSTR", name:"MicroStrategy",  sector:"Crypto",    price:398, iv_rank:85, iv_pct:80, hist_vol:95,  beta:3.2, trend:"bullish", earnings:"Jul 28", w52h:543, w52l:111, ath:543 },
  { ticker:"COIN", name:"Coinbase",        sector:"Crypto",    price:248, iv_rank:78, iv_pct:70, hist_vol:85,  beta:2.8, trend:"bullish", earnings:"Aug 7",  w52h:430, w52l:129, ath:430 },
  { ticker:"TSLA", name:"Tesla",           sector:"EV/Auto",   price:340, iv_rank:71, iv_pct:65, hist_vol:72,  beta:2.1, trend:"bullish", earnings:"Jul 23", w52h:480, w52l:138, ath:480 },
  { ticker:"PLTR", name:"Palantir",        sector:"AI/SW",     price:124, iv_rank:68, iv_pct:62, hist_vol:60,  beta:2.2, trend:"bullish", earnings:"Aug 4",  w52h:140, w52l:20,  ath:140 },
  { ticker:"NVDA", name:"NVIDIA",          sector:"Semis",     price:224, iv_rank:62, iv_pct:58, hist_vol:45,  beta:1.42,trend:"bullish", earnings:"Aug 26", w52h:236, w52l:135, ath:236 },
  { ticker:"AMD",  name:"AMD",             sector:"Semis",     price:168, iv_rank:55, iv_pct:50, hist_vol:48,  beta:1.8, trend:"bullish", earnings:"Jul 29", w52h:227, w52l:117, ath:227 },
  { ticker:"SOFI", name:"SoFi",            sector:"Fintech",   price:14,  iv_rank:50, iv_pct:48, hist_vol:55,  beta:1.9, trend:"neutral", earnings:"Jul 29", w52h:28,  w52l:6,   ath:28  },
  { ticker:"AMZN", name:"Amazon",          sector:"Cloud",     price:222, iv_rank:48, iv_pct:45, hist_vol:28,  beta:1.2, trend:"bullish", earnings:"Aug 1",  w52h:242, w52l:151, ath:242 },
  { ticker:"META", name:"Meta",            sector:"Social",    price:608, iv_rank:44, iv_pct:40, hist_vol:30,  beta:1.3, trend:"bullish", earnings:"Jul 30", w52h:740, w52l:414, ath:740 },
  { ticker:"AAPL", name:"Apple",           sector:"Tech",      price:213, iv_rank:38, iv_pct:42, hist_vol:22,  beta:1.2, trend:"neutral", earnings:"Jul 31", w52h:260, w52l:164, ath:260 },
  { ticker:"GOOGL",name:"Alphabet",        sector:"Tech/Ad",   price:178, iv_rank:36, iv_pct:38, hist_vol:24,  beta:1.1, trend:"neutral", earnings:"Jul 29", w52h:208, w52l:140, ath:208 },
  { ticker:"MSFT", name:"Microsoft",       sector:"Tech",      price:448, iv_rank:30, iv_pct:32, hist_vol:20,  beta:0.9, trend:"bullish", earnings:"Jul 30", w52h:470, w52l:344, ath:470 },
  { ticker:"QQQ",  name:"Nasdaq ETF",      sector:"ETF",       price:516, iv_rank:32, iv_pct:34, hist_vol:16,  beta:1.1, trend:"bullish", earnings:"N/A",    w52h:540, w52l:400, ath:540 },
  { ticker:"SPY",  name:"S&P 500 ETF",     sector:"ETF",       price:592, iv_rank:28, iv_pct:30, hist_vol:14,  beta:1.0, trend:"bullish", earnings:"N/A",    w52h:614, w52l:480, ath:614 },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function getIV(r){ if(r>=70)return{label:"SPIKING",color:"#ff4d4d",bg:"#ff4d4d14"}; if(r>=50)return{label:"ELEVATED",color:"#ffd700",bg:"#ffd70010"}; if(r>=30)return{label:"NORMAL",color:"#778",bg:"#77777708"}; return{label:"CRUSHED",color:"#00ff9d",bg:"#00ff9d0c"}; }
function getEdge(d){ const g=(d.iv_pct||0)-(d.hist_vol||0); if((d.iv_rank||0)>=70)return{text:"Sell premium",color:"#ff4d4d"}; if((d.iv_rank||0)<=35&&d.trend==="bullish")return{text:"BUY calls — cheap",color:"#00ff9d"}; if(g>10)return{text:"Big move priced in",color:"#ffd700"}; if(g<-5)return{text:"Edge for buyers",color:"#00ff9d"}; return{text:"Neutral",color:"#556"}; }
function getMomentumScore(live, base){ let s=5; if(live.trend==="bullish"||base.trend==="bullish") s+=2; if(live.aboveEma9) s+=1; if(live.aboveEma20) s+=0.5; if(live.aboveVwap) s+=0.5; if(live.volSpike) s+=1; if((live.rsi||50)>55&&(live.rsi||50)<70) s+=1; return Math.min(10,Math.max(1,Math.round(s))); }
function getSignalColor(sig){ const map={"BREAKOUT_UP":"#00ff9d","VOL_BREAKOUT":"#00ff9d","VWAP_RECLAIM":"#00ff9d","EMA9_BOUNCE":"#00ff9d","RSI_MOMENTUM":"#ffd700","VWAP_LOSS":"#ff4d4d","BREAKOUT_DOWN":"#ff4d4d","UPDATE":"#445"}; return map[sig]||"#445"; }

// ── UI ────────────────────────────────────────────────────────────────────────
const BG="#070909",PANEL="#0b0f0b",BORDER="#1c2a1c",DIM="#3a4a3a";
const GREEN="#00ff9d",RED="#ff4d6d",GOLD="#ffd700";

function Bar({v,c,max=100}){ return <div style={{background:"#0d1a0d",borderRadius:3,height:4,width:"100%"}}><div style={{background:c,height:4,borderRadius:3,width:`${Math.min((v/max)*100,100)}%`,transition:"width 0.5s ease"}}/></div>; }
function Ring({s,sz=52}){ const r=sz*.38,ci=2*Math.PI*r,c=s>=7?GREEN:s>=5?GOLD:RED,sw=sz*.09; return <svg width={sz} height={sz}><circle cx={sz/2} cy={sz/2} r={r} fill="none" stroke="#1a2a1a" strokeWidth={sw}/><circle cx={sz/2} cy={sz/2} r={r} fill="none" stroke={c} strokeWidth={sw} strokeDasharray={ci} strokeDashoffset={ci*(1-s/10)} strokeLinecap="round" transform={`rotate(-90 ${sz/2} ${sz/2})`}/><text x={sz/2} y={sz/2+sz*.11} textAnchor="middle" fill={c} style={{fontSize:sz*.25,fontFamily:"'Bebas Neue',sans-serif"}}>{s}</text></svg>; }

// ── SETUP SCREEN ──────────────────────────────────────────────────────────────
function Setup({ onConnect }) {
  const [url, setUrl] = useState("");
  const [testing, setTesting] = useState(false);
  const [status, setStatus] = useState(null);

  const test = async () => {
    if (!url.trim()) return;
    setTesting(true); setStatus(null);
    try {
      const clean = url.trim().replace(/\/$/, "");
      const res = await fetch(`${clean}/health`);
      if (res.ok) {
        const d = await res.json();
        setStatus({ ok: true, msg: `Connected! ${d.tickers} tickers tracked.` });
        setTimeout(() => onConnect(clean), 1000);
      } else {
        setStatus({ ok: false, msg: `Server responded with ${res.status}. Check URL.` });
      }
    } catch(e) {
      setStatus({ ok: false, msg: `Can't reach server. Is it deployed? (${e.message})` });
    }
    setTesting(false);
  };

  return (
    <div style={{minHeight:"100vh",background:BG,fontFamily:"'Share Tech Mono',monospace",color:"#c8d0d8",padding:"20px 16px"}}>
      <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Bebas+Neue&display=swap" rel="stylesheet"/>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{fontSize:9,color:`${GREEN}44`,letterSpacing:4,marginBottom:6}}>◈ WEEKLY OPTIONS SYSTEM</div>
          <div style={{fontFamily:"'Bebas Neue'",fontSize:36,color:"#fff",letterSpacing:4,lineHeight:1}}>
            <span style={{color:GREEN}}>LIVE</span> DATA SETUP
          </div>
          <div style={{fontSize:11,color:DIM,marginTop:8,lineHeight:1.8}}>Connect your TradingView webhook server<br/>to get real-time prices and signals</div>
        </div>

        {/* Steps */}
        {[
          ["1","Create Render.com account","render.com → sign up free"],
          ["2","Upload server files to GitHub","server.js + package.json (provided below)"],
          ["3","Deploy on Render","New Web Service → connect GitHub repo → Free plan"],
          ["4","Add Pine Script to TradingView","Paste script → create alerts with your webhook URL"],
          ["5","Paste your server URL below","https://your-app.onrender.com"],
        ].map(([n,title,sub])=>(
          <div key={n} style={{display:"flex",gap:12,padding:"12px 0",borderBottom:`1px solid ${BORDER}`,alignItems:"flex-start"}}>
            <div style={{width:24,height:24,borderRadius:"50%",background:`${GREEN}22`,border:`1px solid ${GREEN}44`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontFamily:"'Bebas Neue'",fontSize:13,color:GREEN}}>{n}</div>
            <div>
              <div style={{fontSize:11,color:"#c8d0d8",marginBottom:2}}>{title}</div>
              <div style={{fontSize:9,color:DIM}}>{sub}</div>
            </div>
          </div>
        ))}

        <div style={{marginTop:24,background:PANEL,border:`1px solid ${BORDER}`,borderRadius:10,padding:18}}>
          <div style={{fontSize:9,color:`${GREEN}66`,letterSpacing:3,marginBottom:10}}>YOUR RENDER SERVER URL</div>
          <input value={url} onChange={e=>setUrl(e.target.value)}
            placeholder="https://options-webhook-xxxx.onrender.com"
            style={{width:"100%",boxSizing:"border-box",background:"#080c08",border:`1px solid ${BORDER}`,borderRadius:6,color:GREEN,fontSize:12,padding:"10px 14px",outline:"none",fontFamily:"'Share Tech Mono'",caretColor:GREEN,marginBottom:10}}
            onFocus={e=>e.target.style.borderColor=GREEN} onBlur={e=>e.target.style.borderColor=BORDER}
            onKeyDown={e=>e.key==="Enter"&&test()}/>
          <button onClick={test} disabled={testing||!url.trim()}
            style={{width:"100%",background:testing?"#0a0f0a":GREEN,border:"none",borderRadius:7,color:"#000",cursor:testing||!url.trim()?"not-allowed":"pointer",fontFamily:"'Bebas Neue'",fontSize:14,letterSpacing:3,padding:"12px 0",transition:"all 0.2s"}}>
            {testing?"CONNECTING...":"CONNECT SERVER"}
          </button>
          {status&&<div style={{marginTop:10,padding:"10px 12px",borderRadius:6,background:status.ok?`${GREEN}11`:`${RED}11`,border:`1px solid ${status.ok?GREEN+33:RED+33}`,fontSize:11,color:status.ok?GREEN:RED}}>{status.msg}</div>}
        </div>

        <div style={{marginTop:16,background:PANEL,border:`1px solid ${BORDER}`,borderRadius:10,padding:16}}>
          <div style={{fontSize:9,color:GOLD+"88",letterSpacing:3,marginBottom:10}}>SKIP FOR NOW — USE STATIC DATA</div>
          <div style={{fontSize:10,color:DIM,marginBottom:12,lineHeight:1.7}}>You can use the scanner with hardcoded prices now and connect live data later once Render is set up.</div>
          <button onClick={()=>onConnect(null)} style={{width:"100%",background:"transparent",border:`1px solid ${BORDER}`,borderRadius:7,color:DIM,cursor:"pointer",fontFamily:"'Bebas Neue'",fontSize:12,letterSpacing:3,padding:"10px 0"}}>USE STATIC DATA →</button>
        </div>
      </div>
    </div>
  );
}

// ── MAIN SCANNER ──────────────────────────────────────────────────────────────
function LiveScanner({ serverUrl, onDisconnect, onSelect, selected }) {
  const [liveData, setLiveData] = useState({});
  const [lastFetch, setLastFetch] = useState(null);
  const [fetchStatus, setFetchStatus] = useState("idle");
  const [ivF, setIvF] = useState("All");
  const [srt, setSrt] = useState("Signal");
  const [flash, setFlash] = useState(false);
  const intervalRef = useRef(null);

  const fetchData = async () => {
    if (!serverUrl) return;
    setFetchStatus("fetching");
    try {
      const res = await fetch(`${serverUrl}/data`);
      if (res.ok) {
        const json = await res.json();
        setLiveData(json.data || {});
        setLastFetch(new Date());
        setFlash(true); setTimeout(()=>setFlash(false), 500);
        setFetchStatus("ok");
      } else { setFetchStatus("error"); }
    } catch { setFetchStatus("error"); }
  };

  useEffect(() => {
    if (!serverUrl) return;
    fetchData();
    intervalRef.current = setInterval(fetchData, 30000); // auto-refresh every 30s
    return () => clearInterval(intervalRef.current);
  }, [serverUrl]);

  // Merge live + static data
  const merged = STATIC_DB.map(base => {
    const live = liveData[base.ticker] || {};
    const hasLive = !!live.price;
    const score = hasLive ? getMomentumScore(live, base) : null;
    return {
      ...base,
      price:      hasLive ? live.price      : base.price,
      rsi:        hasLive ? live.rsi        : null,
      aboveEma9:  hasLive ? live.aboveEma9  : null,
      aboveEma20: hasLive ? live.aboveEma20 : null,
      aboveVwap:  hasLive ? live.aboveVwap  : null,
      volSpike:   hasLive ? live.volSpike   : false,
      pdHigh:     hasLive ? live.pdHigh     : null,
      pdLow:      hasLive ? live.pdLow      : null,
      vwap:       hasLive ? live.vwap       : null,
      trend:      hasLive ? live.trend      : base.trend,
      signal:     hasLive ? live.signal     : "",
      liveScore:  score,
      isLive:     hasLive,
      updatedAt:  hasLive ? live.updatedAt  : null,
    };
  });

  const liveCount = merged.filter(d=>d.isLive).length;

  // Filter
  let rows = merged.filter(d => {
    if (ivF==="Spiking"&&d.iv_rank<70)   return false;
    if (ivF==="Elevated"&&(d.iv_rank<50||d.iv_rank>=70)) return false;
    if (ivF==="Crushed"&&d.iv_rank>=30)  return false;
    if (ivF==="Live Only"&&!d.isLive)    return false;
    if (ivF==="Signals"&&!d.signal&&d.signal!=="BREAKOUT_UP"&&d.signal!=="VOL_BREAKOUT"&&d.signal!=="VWAP_RECLAIM") return false;
    return true;
  });

  // Sort
  rows = [...rows].sort((a,b) => {
    if (srt==="Signal") { const hasSigA=a.signal&&a.signal!=="UPDATE"&&a.signal!=="",hasSigB=b.signal&&b.signal!=="UPDATE"&&b.signal!==""; if(hasSigA&&!hasSigB)return -1; if(!hasSigA&&hasSigB)return 1; return b.iv_rank-a.iv_rank; }
    if (srt==="IV ↓") return b.iv_rank-a.iv_rank;
    if (srt==="Score") return (b.liveScore||b.iv_rank/10)-(a.liveScore||a.iv_rank/10);
    if (srt==="Live First") return (b.isLive?1:0)-(a.isLive?1:0);
    return a.ticker.localeCompare(b.ticker);
  });

  const spk=merged.filter(d=>d.iv_rank>=70).length;
  const elv=merged.filter(d=>d.iv_rank>=50&&d.iv_rank<70).length;
  const crs=merged.filter(d=>d.iv_rank<30).length;
  const sigs=merged.filter(d=>d.signal&&d.signal!=="UPDATE"&&d.signal!=="").length;

  return (
    <div>
      {/* Status bar */}
      <div style={{background:PANEL,border:`1px solid ${BORDER}`,borderRadius:8,padding:"10px 14px",marginBottom:10,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:8,height:8,borderRadius:"50%",background:serverUrl?(fetchStatus==="ok"?GREEN:fetchStatus==="error"?RED:GOLD):"#445",animation:serverUrl&&fetchStatus==="ok"?"pulse 2s infinite":"none"}}/>
          <div>
            <div style={{fontSize:10,color:serverUrl?GREEN:"#445",letterSpacing:1}}>{serverUrl?"LIVE DATA CONNECTED":"STATIC DATA MODE"}</div>
            {lastFetch&&<div style={{fontSize:8,color:DIM}}>Last update: {lastFetch.toLocaleTimeString()}</div>}
            {!serverUrl&&<div style={{fontSize:8,color:DIM}}>Connect Render server for live prices</div>}
          </div>
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          {serverUrl&&<span style={{fontSize:10,color:flash?GREEN:DIM,transition:"color 0.3s",fontFamily:"'Share Tech Mono'"}}>{liveCount}/{merged.length} live</span>}
          <button onClick={fetchData} style={{background:"#0d1a0d",border:`1px solid ${BORDER}`,borderRadius:5,color:GREEN,cursor:"pointer",fontSize:9,fontFamily:"'Bebas Neue'",letterSpacing:2,padding:"5px 10px"}}
            onMouseEnter={e=>{e.target.style.background=GREEN;e.target.style.color="#000";}}
            onMouseLeave={e=>{e.target.style.background="#0d1a0d";e.target.style.color=GREEN;}}>↻</button>
          {serverUrl&&<button onClick={onDisconnect} style={{background:"transparent",border:`1px solid ${BORDER}`,borderRadius:5,color:DIM,cursor:"pointer",fontSize:9,fontFamily:"'Share Tech Mono'",padding:"5px 10px"}}>SETTINGS</button>}
        </div>
      </div>

      {/* Summary cards */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,marginBottom:10}}>
        {[["🔴 SPIKING",spk,"#ff4d4d"],["🟡 ELEVATED",elv,GOLD],["🟢 CRUSHED",crs,GREEN],["⚡ SIGNALS",sigs,"#4d9fff"]].map(([l,v,c])=>(
          <div key={l} style={{background:PANEL,border:`1px solid ${BORDER}`,borderRadius:8,padding:"10px 8px",textAlign:"center"}}>
            <div style={{fontSize:7,color:DIM,letterSpacing:2,marginBottom:3}}>{l}</div>
            <div style={{fontFamily:"'Bebas Neue'",fontSize:22,color:c,letterSpacing:2}}>{v}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{background:PANEL,border:`1px solid ${BORDER}`,borderRadius:8,padding:"10px 12px",marginBottom:10}}>
        <div style={{display:"flex",gap:4,flexWrap:"wrap",marginBottom:6}}>
          {["All","Live Only","Signals","Spiking","Elevated","Crushed"].map(f=>(
            <button key={f} onClick={()=>setIvF(f)} style={{background:ivF===f?"#ff4d4d22":"#0d1a0d",border:`1px solid ${ivF===f?"#ff4d4d55":BORDER}`,borderRadius:4,color:ivF===f?"#ff4d4d":DIM,cursor:"pointer",fontSize:8,fontFamily:"'Share Tech Mono'",padding:"4px 9px"}}>{f}</button>
          ))}
        </div>
        <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
          {["Signal","IV ↓","Score","Live First","A-Z"].map(s=>(
            <button key={s} onClick={()=>setSrt(s)} style={{background:srt===s?"#ffd70018":"#0d1a0d",border:`1px solid ${srt===s?"#ffd70044":BORDER}`,borderRadius:4,color:srt===s?GOLD:DIM,cursor:"pointer",fontSize:8,fontFamily:"'Share Tech Mono'",padding:"4px 9px"}}>{s}</button>
          ))}
        </div>
      </div>

      <div style={{fontSize:8,color:DIM,letterSpacing:2,marginBottom:8}}>SHOWING {rows.length}/{merged.length} · {liveCount} LIVE</div>

      {/* Rows */}
      {rows.map(d => {
        const {color,bg}=getIV(d.iv_rank),edge=getEdge(d),isSel=selected===d.ticker;
        const sigColor = d.signal ? getSignalColor(d.signal) : DIM;
        const score = d.liveScore || Math.round(d.iv_rank/12);
        const ageMs = d.updatedAt ? Date.now()-new Date(d.updatedAt).getTime() : null;
        const ageMin = ageMs ? Math.floor(ageMs/60000) : null;
        return (
          <div key={d.ticker} onClick={()=>onSelect(d.ticker)}
            style={{background:isSel?"#0d1a10":bg,border:`1px solid ${isSel?color:"transparent"}`,borderLeft:`3px solid ${d.signal&&d.signal!=="UPDATE"?sigColor:d.isLive?GREEN+"44":"transparent"}`,borderRadius:8,padding:"10px 12px",marginBottom:5,cursor:"pointer",transition:"all 0.15s"}}
            onMouseEnter={e=>!isSel&&(e.currentTarget.style.background="#0b0f0b")}
            onMouseLeave={e=>!isSel&&(e.currentTarget.style.background=bg)}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <div>
                  <div style={{display:"flex",alignItems:"center",gap:6}}>
                    <div style={{fontFamily:"'Bebas Neue'",fontSize:17,color:"#fff",letterSpacing:2,lineHeight:1}}>{d.ticker}</div>
                    {d.isLive&&<div style={{width:5,height:5,borderRadius:"50%",background:GREEN,flexShrink:0}}/>}
                  </div>
                  <div style={{fontSize:8,color:DIM,marginTop:1}}>{d.name}</div>
                </div>
                <div>
                  <div style={{fontFamily:"'Bebas Neue'",fontSize:18,color:"#fff",letterSpacing:1}}>${d.price}</div>
                  {ageMin!==null&&<div style={{fontSize:7,color:DIM}}>{ageMin<1?"just now":`${ageMin}m ago`}</div>}
                </div>
              </div>
              <div style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                {d.signal&&d.signal!=="UPDATE"&&d.signal!==""&&(
                  <div style={{fontSize:8,color:sigColor,background:`${sigColor}18`,border:`1px solid ${sigColor}44`,borderRadius:4,padding:"2px 7px",letterSpacing:1,whiteSpace:"nowrap"}}>{d.signal.replace("_"," ")}</div>
                )}
                <div style={{textAlign:"right"}}>
                  <div style={{fontFamily:"'Bebas Neue'",fontSize:18,color,letterSpacing:1,lineHeight:1}}>{d.iv_rank}</div>
                  <div style={{fontSize:7,color,letterSpacing:1}}>{getIV(d.iv_rank).label}</div>
                </div>
              </div>
            </div>

            {/* Live indicators */}
            {d.isLive&&(
              <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:6}}>
                {[
                  ["EMA9",d.aboveEma9],["EMA20",d.aboveEma20],["VWAP",d.aboveVwap],["VOL↑",d.volSpike]
                ].map(([l,v])=>(
                  <div key={l} style={{fontSize:8,color:v?GREEN:RED,background:v?`${GREEN}11`:`${RED}11`,border:`1px solid ${v?GREEN+33:RED+33}`,borderRadius:3,padding:"1px 6px"}}>{v?"✓":"✗"} {l}</div>
                ))}
                {d.rsi&&<div style={{fontSize:8,color:d.rsi>55&&d.rsi<70?GREEN:d.rsi>=70?RED:DIM,background:"#0d1a0d",border:`1px solid ${BORDER}`,borderRadius:3,padding:"1px 6px"}}>RSI {d.rsi?.toFixed(1)}</div>}
              </div>
            )}

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:5}}>
              <div><div style={{display:"flex",justifyContent:"space-between",fontSize:7,color:DIM,marginBottom:2}}><span>IV {d.iv_pct}%</span>{d.isLive&&<span style={{color:GREEN}}>LIVE</span>}</div><Bar v={d.iv_pct} c={color}/></div>
              <div><div style={{fontSize:7,color:DIM,marginBottom:2}}>Edge: <span style={{color:edge.color}}>{edge.text}</span></div><Bar v={d.hist_vol} c="#2a4a2a"/></div>
            </div>
          </div>
        );
      })}

      {/* Legend */}
      <div style={{marginTop:12,background:PANEL,border:`1px solid ${BORDER}`,borderRadius:8,padding:"10px 12px"}}>
        <div style={{fontSize:7,color:DIM,letterSpacing:3,marginBottom:8}}>SIGNAL KEY</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
          {[["BREAKOUT UP","#00ff9d"],["VOL BREAKOUT","#00ff9d"],["VWAP RECLAIM","#00ff9d"],["EMA9 BOUNCE","#00ff9d"],["RSI MOMENTUM","#ffd700"],["VWAP LOSS","#ff4d4d"],["BREAKOUT DOWN","#ff4d4d"]].map(([s,c])=>(
            <div key={s} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:6,height:6,borderRadius:1,background:c,flexShrink:0}}/>
              <span style={{fontSize:8,color:DIM}}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────────────────────
export default function App(){
  const [serverUrl, setServerUrl] = useState(null);
  const [setupDone, setSetupDone] = useState(false);
  const [selected, setSelected] = useState("NVDA");

  // Try to load saved server URL
  useEffect(()=>{
    const saved = localStorage.getItem("webhook_server_url");
    if(saved){ setServerUrl(saved); setSetupDone(true); }
    else { setSetupDone(false); }
  },[]);

  const connect = (url) => {
    if(url) localStorage.setItem("webhook_server_url", url);
    setServerUrl(url);
    setSetupDone(true);
  };

  const disconnect = () => {
    localStorage.removeItem("webhook_server_url");
    setServerUrl(null);
    setSetupDone(false);
  };

  if(!setupDone) return <Setup onConnect={connect}/>;

  return (
    <div style={{minHeight:"100vh",background:BG,fontFamily:"'Share Tech Mono',monospace",color:"#c8d0d8"}}>
      <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Bebas+Neue&display=swap" rel="stylesheet"/>
      <div style={{position:"fixed",inset:0,pointerEvents:"none",backgroundImage:"linear-gradient(rgba(0,255,100,0.012) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,100,0.012) 1px,transparent 1px)",backgroundSize:"40px 40px"}}/>
      <div style={{background:"#080c08",borderBottom:`1px solid ${BORDER}`,padding:"10px 14px",position:"sticky",top:0,zIndex:100}}>
        <div style={{fontFamily:"'Bebas Neue'",fontSize:20,letterSpacing:3,lineHeight:1}}>
          <span style={{color:"#ff4d4d"}}>WEEKLY </span><span style={{color:GREEN}}>OPTIONS</span>
          <span style={{fontSize:9,color:DIM,letterSpacing:3,marginLeft:10}}>LIVE SCANNER</span>
        </div>
      </div>
      <div style={{padding:"12px 12px 40px",position:"relative",zIndex:1}}>
        <LiveScanner serverUrl={serverUrl} onDisconnect={disconnect} onSelect={setSelected} selected={selected}/>
      </div>
    </div>
  );
}
